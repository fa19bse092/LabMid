
package midlab_dp;
import java.util.*;
class VisaBuilder{
    String nname;
    String nationality ;
    int age;
    String gender;
    String purposeOfVisa;
    Scanner sc = new Scanner(System.in);
    public void CollectData(){
    System.out.println("Visa Form");
    System.out.println("****************");
    System.out.println("Enter your Name: ");
    nname = sc.nextLine();
    
    System.out.println("Enter your Nationality: ");
    nationality = sc.nextLine();
     System.out.println("Enter your age: ");
    age = sc.nextInt();
    System.out.println("Enter your gender: ");
    gender = sc.nextLine(); 
    System.out.println("Enter purpose of visa: ");
    purposeOfVisa = sc.nextLine();
    VisaConBuilder obj = new VisaConBuilder(
    nname,nationality,age,gender,purposeOfVisa);
    obj.creatVisa();
    }
    
    
}
class VisaConBuilder{
    String mname;
    String nationality ; 
    int age;
    String gender;
    String purposeOfVisa;
    BusniseVisa Bobj;
    StudyVisa Sobj;
    VisaVisit Vobj;
    VisaConBuilder(String name,String nat, int age, String gender, String purpose ){
        this.mname = name;
        this.nationality = nat;
        this.age = age;
        this.gender = gender;
        this.purposeOfVisa = purpose;
    }
    public void creatVisa(){
        if(this.purposeOfVisa.contentEquals("Busnise")){
               Bobj.creatVisa();
            
        }
        else if(this.purposeOfVisa.contentEquals("Study")){
               Sobj.creatVisa();
            
        }
        else if(this.purposeOfVisa.contentEquals("Visit")){
               Vobj.creatVisa();
            
        }
        else{
            System.out.println("You Chose Nothing ");
        }
    }
    
}
class BusniseVisa extends VisaConBuilder {

    public BusniseVisa(String name,String nat, int age, String gender, String purpose) {
        super(name,nat, age, gender, purpose);
    }
    @Override
    public void creatVisa(){
        System.out.println("-------- This is Busnise Visa --------- ");
        System.out.println("Your Name is : "+super.mname);
        System.out.println("Your Nationality is : "+super.nationality);
        System.out.println("Your Age is : "+super.age);
        System.out.println("Your Gender is : "+super.gender);  
        System.out.println("Your Purpose of Visa  is : "+super.purposeOfVisa);
        
    }
    
}
class StudyVisa extends VisaConBuilder{
      public StudyVisa(String name,String nat, int age, String gender, String purpose) {
        super(name,nat, age, gender, purpose);
    }
    @Override
    public void creatVisa(){
        System.out.println("-------- This is Study Visa --------- ");
        System.out.println("Your Name is : "+super.mname);
        System.out.println("Your Nationality is : "+super.nationality);
        System.out.println("Your Age is : "+super.age);
        System.out.println("Your Gender is : "+super.gender);  
        System.out.println("Your Purpose of Visa  is : "+super.purposeOfVisa);
        
    }
    
}
class VisaVisit extends VisaConBuilder{
      public VisaVisit(String name,String nat, int age, String gender, String purpose) {
        super(name,nat, age, gender, purpose);
    }
    @Override
    public void creatVisa(){
        System.out.println("-------- This is Visit Visa --------- ");
        System.out.println("Your Name is : "+super.mname);
        System.out.println("Your Nationality is : "+super.nationality);
        System.out.println("Your Age is : "+super.age);
        System.out.println("Your Gender is : "+super.gender);  
        System.out.println("Your Purpose of Visa  is : "+super.purposeOfVisa);
        
    }
    
}
class VisaDirect{ 
    VisaBuilder myobj = new VisaBuilder();
    public void requestVisa(){
    myobj.CollectData();
    }
    
}
public class MidLab_Dp {

    public static void main(String[] args) {
        System.out.println("Create Me A Visa ");
        VisaDirect obj = new VisaDirect();
        obj.requestVisa();
        
    }
    
}
